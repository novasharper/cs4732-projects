Patrick Long (pllong@wpi.edu)
CS 4732
Project 0

Hello Cube!

For this project I used Unity, specifically Unity 5.4.3, so this or a later version will definitely work.
I think earlier versions will work as well. Basically, what I did was add a Cube, then add the script
Animate to the Cube. Animate rotates the cube 10 degrees per second.

To open the program, just go to the Assets folder and open "main.unity" with Unity Editor.
To run, just play the game/simulation (press the play button).

Video: https://youtu.be/PGbPAe4mO80