Patrick Long (pllong@wpi.edu)
CS 4732
Project 1

Take a Walk on the Wild Side!!

For this project I used Unity, specifically Unity 5.5.2. Earlier versions should work as well.
The thing that I am simulating with this project is a Sci-Fi Spaceship. It starts in a vertical
hovering position, then transitions to fly forwards. Next it animates to fly in a circlish shape.
Then the ship does some rotational maneuvers while lowering itself toward the ground. The two
changes with FollowSpline were removing the code to display  themotion trail and control points
and adding in the conversion from degrees to radians at the start of EulerToQuat.

To open the program, just go to the Assets folder and open "spline.unity" with Unity Editor.
To run, just play the game/simulation (press the play button).

Video: https://youtu.be/SgO44J1moQU